﻿namespace MultiMiner.Engine.Data
{
    public class MinerNames
    {
        public const string BFGMiner = "BFGMiner";
        public const string CGMiner = "CGMiner";
        public const string SGMiner = "SGMiner";
        public const string SGMiner5 = "SGMiner5";
        public const string SPHSGMiner = "SPHSGMiner";
        public const string KalrothSJCGMiner = "KalrothSJCGMiner";
        public const string LBSPHSGMiner = "LBSPHSGMiner";
        public const string AZNSGMiner = "AZNSGMiner";
        public const string MaxcoinCGMiner = "MaxcoinCGMiner";
    }
}
