﻿namespace MultiMiner.Engine.Data.Configuration
{
    public enum ListViewStyle
    {
        LargeIcon = 0,
        Details = 1,
        SmallIcon = 2,
        List = 3,
        Tile = 4
    }
}
