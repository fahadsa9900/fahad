﻿using MultiMiner.Engine.Data.Configuration;
using MultiMiner.Xgminer.Data;

namespace MultiMiner.TUI.Data
{
    struct PoolListEntry
    {
        public Coin Configuration;
        public MiningPool Pool;
    }
}
