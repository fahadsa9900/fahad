﻿namespace MultiMiner.TUI.Data
{
    class ScreenNames
    {
        public const string Main = "main";
        public const string Repl = "repl";
        public const string ApiLog = "apilog";
        public const string History = "history";
        public const string ProcLog = "proclog";
    }
}
