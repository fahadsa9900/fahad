﻿namespace MultiMiner.Remoting.Broadcast
{
    public class Packet
    {
        public string Descriptor { get; set; }
        public string Payload { get; set; }
    }
}
