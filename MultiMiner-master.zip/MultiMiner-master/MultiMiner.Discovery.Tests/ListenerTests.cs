﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Sockets;

namespace MultiMiner.Discovery.Tests
{
    [TestClass]
    public class ListenerTests
    {
    }
}
