﻿namespace MultiMiner.Xgminer.Data
{
    public class KnownAlgorithm
    {
        public string Name { get; set; }
        public string FullName { get; set; }
        public double Multiplier { get; set; }
    }
}
