﻿namespace MultiMiner.Stats.Data
{
    public class Machine
    {
        public string Name { get; set; }
        public string MinerVersion { get; set; }
    }
}
