﻿namespace MultiMiner.Discovery
{
    class Config
    {
        private const int UserPortMin = 49152;
        public const int Port = UserPortMin + 1474;
    }
}
