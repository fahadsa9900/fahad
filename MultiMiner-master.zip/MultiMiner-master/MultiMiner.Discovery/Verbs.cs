﻿namespace MultiMiner.Discovery
{
    public static class Verbs
    {
        public const string Online = "Online";
        public const string Offline = "Offline";
    }
}
