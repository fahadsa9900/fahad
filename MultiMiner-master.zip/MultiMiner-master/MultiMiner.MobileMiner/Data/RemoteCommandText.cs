﻿namespace MultiMiner.MobileMiner.Data
{
    public static class RemoteCommandText
    {
        public const string Start = "START";
        public const string Stop = "STOP";
        public const string Restart = "RESTART";
        public const string Switch = "SWITCH";
    }
}
