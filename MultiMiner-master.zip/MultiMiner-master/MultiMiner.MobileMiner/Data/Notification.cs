﻿namespace MultiMiner.MobileMiner.Data
{
    public class Notification
    {
        public string NotificationText { get; set; }
        public NotificationKind NotificationKind { get; set; }
        public string MachineName { get; set; }
    }
}
