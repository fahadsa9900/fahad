namespace MultiMiner.MobileMiner.Data
{
    public enum NotificationKind
    {
        Default,
        Success,
        Primary,
        Information,
        Warning,
        Danger
    }
}
