﻿namespace MultiMiner.UX.Data
{
    public static class UserAgent
    {
        public const string AgentString = "MultiMiner/V3";
    }
}
