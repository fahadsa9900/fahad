﻿namespace MultiMiner.UX.Data
{
    public class PoolFeatureAnchors
    {
        public const string ExtraNonceSubscribe = "#xnsub";
        public const string SkipCoinbaseCheck = "#skipcbcheck";
    }
}
