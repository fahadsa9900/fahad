﻿namespace MultiMiner.UX.Data.Configuration
{
    public static class PoolDefaults
    {
        public const string HostPrefix = "stratum+tcp://";
        public const int Port = 3333;
    }
}
