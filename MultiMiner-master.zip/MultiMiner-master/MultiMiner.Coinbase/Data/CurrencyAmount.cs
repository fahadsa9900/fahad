﻿namespace MultiMiner.Coinbase.Data
{
    public class CurrencyAmount
    {
        public string Currency { get; set; }
        public double Amount { get; set; }
    }
}